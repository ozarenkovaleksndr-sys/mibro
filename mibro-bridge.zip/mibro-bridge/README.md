# Mibro Bridge

Android-приложение, которое читает данные Mibro Fit из Health Connect и отправляет их на wattpeaks.ru.

## Как это работает

Mibro Fit пишет данные в Health Connect на телефоне. Это приложение подписывается на них через Health Connect SDK и шлёт батчами на твой эндпоинт.

Первый запуск делает засев за последние 7 дней и запоминает changes-токен. Дальше ходит только за изменениями через Changes API, поэтому дублей нет и перечитывать всё подряд не приходится. Курсор хранится в SharedPreferences, кнопка «Сбросить курсор» заставляет пересеяться.

Фоном работает WorkManager раз в час. Реальная частота будет плавать: система сама решает, когда будить воркер. Если нужна предсказуемость, отключи для приложения оптимизацию батареи.

## Сборка

Gradle wrapper в комплект не положен. Открой папку в Android Studio, она подтянет wrapper и синхронизирует проект сама. Или из консоли, если есть локальный Gradle:

```
gradle wrapper
./gradlew assembleDebug
```

APK окажется в `app/build/outputs/apk/debug/`. Ставь через `adb install` или скинь на телефон.

Версии зависимостей в `app/build.gradle.kts` могут устареть, Android Studio подсветит более свежие. Особенно посмотри на `androidx.health.connect:connect-client`.

## Настройка

1. В кабинете атлета на сайте сгенерируй токен привязки.
2. В приложении заполни адрес сайта и токен, нажми «Сохранить».
3. Нажми «Выдать доступ к Health Connect» и отметь все типы данных.
4. «Синхронизировать сейчас» для проверки.

Переключатель «Только записи Mibro Fit» фильтрует по пакету-источнику, чтобы не тащить данные от других приложений. Пакет прописан в `Prefs.MIBRO_PACKAGE`, проверь его у себя:

```
adb shell pm list packages | grep -i mibro
```

## Что приложение запрашивает

Тренировки, сон, пульс, ВСР (RMSSD), пульс покоя, SpO2, шаги, дистанцию, скорость, мощность, калории.

Запрошено — не значит, что придёт. Mibro в Health Connect почти наверняка пишет только часть: тренировки, пульс, сон, шаги, SpO2. ВСР и мощности там, скорее всего, не будет вообще. Посмотри после первой синхронизации, что реально приехало, и выкинь из `HealthConnectSource.RECORD_TYPES` лишние типы — меньше разрешений в диалоге, меньше вопросов у атлетов.

Треки маршрутов (`ExerciseRoute`) не запрашиваются: для них нужно отдельное разрешение `READ_EXERCISE_ROUTE` и отдельный флоу подтверждения. Если окажется, что Mibro их пишет, добавим.

## Серверная часть

Приложение шлёт `POST /api/imports/health-connect` с заголовком `Authorization: Bearer <токен привязки>` и телом:

```json
{
  "source": "health_connect",
  "device": "Pixel 7",
  "sentAt": "2026-09-19T10:00:00Z",
  "records": [
    {
      "type": "ExerciseSessionRecord",
      "id": "3f2c...",
      "origin": "com.xiaoxun.xunoversea.mibrofit",
      "lastModified": "2026-09-19T09:58:12Z",
      "start": "2026-09-19T06:00:00Z",
      "startZoneOffset": "+03:00",
      "end": "2026-09-19T07:30:00Z",
      "exerciseType": 8,
      "title": "Cycling"
    }
  ],
  "deletedIds": []
}
```

Миграция:

```php
Schema::create('health_connect_records', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    $table->string('hc_id')->index();          // metadata.id из Health Connect
    $table->string('type');
    $table->string('origin')->nullable();
    $table->timestampTz('starts_at')->nullable()->index();
    $table->timestampTz('ends_at')->nullable();
    $table->timestampTz('last_modified')->nullable();
    $table->jsonb('raw');
    $table->timestamps();
    $table->unique(['user_id', 'hc_id']);
});
```

Контроллер:

```php
public function store(Request $request)
{
    $user = $request->user();   // резолвится по токену привязки

    $data = $request->validate([
        'records' => ['array'],
        'records.*.id' => ['required', 'string'],
        'records.*.type' => ['required', 'string'],
        'deletedIds' => ['array'],
    ]);

    $rows = collect($data['records'] ?? [])->map(fn (array $r) => [
        'user_id' => $user->id,
        'hc_id' => $r['id'],
        'type' => $r['type'],
        'origin' => $r['origin'] ?? null,
        'starts_at' => $r['start'] ?? $r['time'] ?? null,
        'ends_at' => $r['end'] ?? null,
        'last_modified' => $r['lastModified'] ?? null,
        'raw' => json_encode($r),
        'created_at' => now(),
        'updated_at' => now(),
    ])->all();

    foreach (array_chunk($rows, 500) as $chunk) {
        HealthConnectRecord::upsert(
            $chunk,
            ['user_id', 'hc_id'],
            ['type', 'origin', 'starts_at', 'ends_at', 'last_modified', 'raw', 'updated_at']
        );
    }

    if ($ids = $data['deletedIds'] ?? []) {
        HealthConnectRecord::where('user_id', $user->id)->whereIn('hc_id', $ids)->delete();
    }

    return response()->json(['accepted' => count($rows)]);
}
```

Сырой JSON лежит в `raw` как есть, нормализацию в тренировки делай отдельным джобом. Тогда парсер можно переписывать, не выкачивая заново.

Время везде UTC, ISO-8601, зональные смещения приходят отдельными полями (`startZoneOffset`), так что локальный день атлета считается как у тебя уже сделано для Garmin.

Токен привязки проще всего сделать через `createToken` Sanctum с отдельной ability, например `import:health-connect`, и роут закрыть `auth:sanctum` плюс `abilities`. Тогда отзыв доступа — просто удаление токена в кабинете.

## Ограничения, о которых стоит помнить

Health Connect отдаёт приложению записи не старше 30 дней до момента первой выдачи разрешения. Историю так не забрать, только текущий поток. Переустановка приложения обнуляет эту дату.

Если атлет удалит приложение или отзовёт разрешения, поток просто прекратится молча. Стоит на сайте показывать дату последней успешной синхронизации, чтобы это было заметно.
