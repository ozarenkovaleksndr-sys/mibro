package ru.wattpeaks.bridge

import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.HeartRateVariabilityRmssdRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.records.PowerRecord
import androidx.health.connect.client.records.Record
import androidx.health.connect.client.records.RestingHeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.SpeedRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import org.json.JSONArray
import org.json.JSONObject

/**
 * Превращает запись Health Connect в JSON максимально «как есть».
 * Разбирать и нормализовать будем на сервере, тут задача — ничего не потерять.
 */
fun Record.toJson(): JSONObject {
    val o = JSONObject()
    o.put("type", this::class.simpleName)
    o.put("id", metadata.id)
    o.put("origin", metadata.dataOrigin.packageName)
    o.put("lastModified", metadata.lastModifiedTime.toString())
    o.put("clientRecordId", metadata.clientRecordId)

    when (this) {
        is ExerciseSessionRecord -> {
            o.putInterval(startTime.toString(), startZoneOffset?.id, endTime.toString(), endZoneOffset?.id)
            o.put("exerciseType", exerciseType)
            o.put("title", title)
            o.put("notes", notes)
            o.put("segments", JSONArray(segments.map {
                JSONObject()
                    .put("start", it.startTime.toString())
                    .put("end", it.endTime.toString())
                    .put("segmentType", it.segmentType)
                    .put("repetitions", it.repetitions)
            }))
            o.put("laps", JSONArray(laps.map {
                JSONObject()
                    .put("start", it.startTime.toString())
                    .put("end", it.endTime.toString())
                    .put("lengthMeters", it.length?.inMeters)
            }))
        }

        is SleepSessionRecord -> {
            o.putInterval(startTime.toString(), startZoneOffset?.id, endTime.toString(), endZoneOffset?.id)
            o.put("title", title)
            o.put("notes", notes)
            o.put("stages", JSONArray(stages.map {
                JSONObject()
                    .put("start", it.startTime.toString())
                    .put("end", it.endTime.toString())
                    .put("stage", it.stage)
            }))
        }

        is HeartRateRecord -> {
            o.putInterval(startTime.toString(), startZoneOffset?.id, endTime.toString(), endZoneOffset?.id)
            o.put("samples", JSONArray(samples.map {
                JSONObject()
                    .put("time", it.time.toString())
                    .put("bpm", it.beatsPerMinute)
            }))
        }

        is HeartRateVariabilityRmssdRecord -> {
            o.put("time", time.toString())
            o.put("zoneOffset", zoneOffset?.id)
            o.put("rmssdMillis", heartRateVariabilityMillis)
        }

        is RestingHeartRateRecord -> {
            o.put("time", time.toString())
            o.put("zoneOffset", zoneOffset?.id)
            o.put("bpm", beatsPerMinute)
        }

        is OxygenSaturationRecord -> {
            o.put("time", time.toString())
            o.put("zoneOffset", zoneOffset?.id)
            o.put("percentage", percentage.value)
        }

        is StepsRecord -> {
            o.putInterval(startTime.toString(), startZoneOffset?.id, endTime.toString(), endZoneOffset?.id)
            o.put("count", count)
        }

        is DistanceRecord -> {
            o.putInterval(startTime.toString(), startZoneOffset?.id, endTime.toString(), endZoneOffset?.id)
            o.put("meters", distance.inMeters)
        }

        is TotalCaloriesBurnedRecord -> {
            o.putInterval(startTime.toString(), startZoneOffset?.id, endTime.toString(), endZoneOffset?.id)
            o.put("kcal", energy.inKilocalories)
        }

        is ActiveCaloriesBurnedRecord -> {
            o.putInterval(startTime.toString(), startZoneOffset?.id, endTime.toString(), endZoneOffset?.id)
            o.put("kcal", energy.inKilocalories)
        }

        is SpeedRecord -> {
            o.putInterval(startTime.toString(), startZoneOffset?.id, endTime.toString(), endZoneOffset?.id)
            o.put("samples", JSONArray(samples.map {
                JSONObject()
                    .put("time", it.time.toString())
                    .put("mps", it.speed.inMetersPerSecond)
            }))
        }

        is PowerRecord -> {
            o.putInterval(startTime.toString(), startZoneOffset?.id, endTime.toString(), endZoneOffset?.id)
            o.put("samples", JSONArray(samples.map {
                JSONObject()
                    .put("time", it.time.toString())
                    .put("watts", it.power.inWatts)
            }))
        }

        else -> o.put("unsupported", true)
    }
    return o
}

private fun JSONObject.putInterval(start: String, startOffset: String?, end: String, endOffset: String?) {
    put("start", start)
    put("startZoneOffset", startOffset)
    put("end", end)
    put("endZoneOffset", endOffset)
}
