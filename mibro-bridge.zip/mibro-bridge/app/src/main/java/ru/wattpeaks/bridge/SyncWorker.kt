package ru.wattpeaks.bridge

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.time.Instant
import java.util.concurrent.TimeUnit

class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        if (!prefs.isConfigured()) {
            prefs.lastStatus = "не настроено: нет адреса или токена"
            return Result.success()
        }

        val source = HealthConnectSource(applicationContext)
        if (!source.isAvailable()) {
            prefs.lastStatus = "Health Connect недоступен"
            return Result.success()
        }
        if (!source.hasAllPermissions()) {
            prefs.lastStatus = "нет разрешений Health Connect"
            return Result.success()
        }

        return try {
            val sent = runSync(prefs, source)
            prefs.lastStatus = "ок, ${Instant.now()}: отправлено записей $sent"
            Result.success()
        } catch (e: Exception) {
            prefs.lastStatus = "ошибка: ${e.message}"
            Result.retry()
        }
    }

    private suspend fun runSync(prefs: Prefs, source: HealthConnectSource): Int {
        val uploader = Uploader(prefs)
        val token = prefs.changesToken

        if (token == null) {
            // Первый запуск: берём токен ДО чтения, чтобы не потерять изменения,
            // случившиеся во время засева.
            val fresh = source.newChangesToken()
            val records = source.readRecent(SEED_DAYS)
                .filterSource(prefs)
                .map { it.toJson() }
            val sent = uploader.upload(records, emptyList())
            prefs.changesToken = fresh
            return sent
        }

        val changes = source.readChanges(token)
        if (changes.expired) {
            // Токен протух (обычно если приложение долго не запускалось).
            // Сбрасываем и пересеиваемся на следующем проходе.
            prefs.changesToken = null
            return runSync(prefs, source)
        }

        val records = changes.upserts.filterSource(prefs).map { it.toJson() }
        val sent = uploader.upload(records, changes.deletions)
        prefs.changesToken = changes.nextToken
        return sent
    }

    private fun List<androidx.health.connect.client.records.Record>.filterSource(prefs: Prefs) =
        if (prefs.filterMibroOnly) {
            filter { it.metadata.dataOrigin.packageName == Prefs.MIBRO_PACKAGE }
        } else {
            this
        }

    companion object {
        private const val SEED_DAYS = 7L
        private const val UNIQUE_NAME = "mibro_periodic_sync"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<SyncWorker>(1, TimeUnit.HOURS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_NAME)
        }
    }
}
