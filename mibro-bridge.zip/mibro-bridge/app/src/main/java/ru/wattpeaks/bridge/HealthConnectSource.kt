package ru.wattpeaks.bridge

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.changes.DeletionChange
import androidx.health.connect.client.changes.UpsertionChange
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.HeartRateVariabilityRmssdRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.records.PowerRecord
import androidx.health.connect.client.records.Record
import androidx.health.connect.client.records.RestingHeartRateRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.SpeedRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.request.ChangesTokenRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.reflect.KClass

/**
 * Обёртка над Health Connect.
 *
 * Стратегия: первый запуск делает засев за несколько последних дней и запоминает
 * changes-токен. Дальше ходим только за изменениями, поэтому дублей нет и
 * перечитывать всё подряд не нужно.
 */
class HealthConnectSource(private val context: Context) {

    val client: HealthConnectClient by lazy { HealthConnectClient.getOrCreate(context) }

    fun availability(): Int = HealthConnectClient.getSdkStatus(context)

    fun isAvailable(): Boolean = availability() == HealthConnectClient.SDK_AVAILABLE

    suspend fun grantedPermissions(): Set<String> =
        client.permissionController.getGrantedPermissions()

    suspend fun hasAllPermissions(): Boolean =
        grantedPermissions().containsAll(PERMISSIONS)

    /** Свежий токен изменений. Вызывается один раз при первой настройке. */
    suspend fun newChangesToken(): String =
        client.getChangesToken(ChangesTokenRequest(recordTypes = RECORD_TYPES))

    /**
     * Первичный засев: читаем последние [days] дней по всем типам.
     * Health Connect всё равно не отдаст данные старше 30 дней до момента
     * первой выдачи разрешения, так что больше 30 ставить смысла нет.
     */
    suspend fun readRecent(days: Long): List<Record> {
        val end = Instant.now()
        val start = end.minus(days, ChronoUnit.DAYS)
        val filter = TimeRangeFilter.between(start, end)
        val out = mutableListOf<Record>()
        for (type in RECORD_TYPES) {
            var pageToken: String? = null
            do {
                val response = client.readRecords(
                    ReadRecordsRequest(
                        recordType = type,
                        timeRangeFilter = filter,
                        pageToken = pageToken
                    )
                )
                out += response.records
                pageToken = response.pageToken
            } while (pageToken != null)
        }
        return out
    }

    /**
     * Инкрементальная выборка. Возвращает добавленные/изменённые записи,
     * удалённые id и следующий токен. Если токен протух — [ChangesResult.expired].
     */
    suspend fun readChanges(token: String): ChangesResult {
        val upserts = mutableListOf<Record>()
        val deletions = mutableListOf<String>()
        var current = token

        while (true) {
            val response = client.getChanges(current)
            if (response.changesTokenExpired) {
                return ChangesResult(emptyList(), emptyList(), current, expired = true)
            }
            for (change in response.changes) {
                when (change) {
                    is UpsertionChange -> upserts += change.record
                    is DeletionChange -> deletions += change.recordId
                }
            }
            current = response.nextChangesToken
            if (!response.hasMore) break
        }
        return ChangesResult(upserts, deletions, current, expired = false)
    }

    data class ChangesResult(
        val upserts: List<Record>,
        val deletions: List<String>,
        val nextToken: String,
        val expired: Boolean
    )

    companion object {
        val RECORD_TYPES: Set<KClass<out Record>> = setOf(
            ExerciseSessionRecord::class,
            SleepSessionRecord::class,
            HeartRateRecord::class,
            HeartRateVariabilityRmssdRecord::class,
            RestingHeartRateRecord::class,
            OxygenSaturationRecord::class,
            StepsRecord::class,
            DistanceRecord::class,
            TotalCaloriesBurnedRecord::class,
            ActiveCaloriesBurnedRecord::class,
            SpeedRecord::class,
            PowerRecord::class
        )

        val PERMISSIONS: Set<String> =
            RECORD_TYPES.map { HealthPermission.getReadPermission(it) }.toSet()
    }
}
