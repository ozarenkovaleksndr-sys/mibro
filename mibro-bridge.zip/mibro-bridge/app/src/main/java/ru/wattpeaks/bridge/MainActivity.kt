package ru.wattpeaks.bridge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.PermissionController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    BridgeScreen()
                }
            }
        }
    }
}

@Composable
private fun BridgeScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { Prefs(context) }
    val source = remember { HealthConnectSource(context) }

    var baseUrl by remember { mutableStateOf(prefs.baseUrl) }
    var token by remember { mutableStateOf(prefs.pairingToken) }
    var mibroOnly by remember { mutableStateOf(prefs.filterMibroOnly) }
    var permissionsOk by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf(prefs.lastStatus) }
    var busy by remember { mutableStateOf(false) }

    val availability = remember { source.availability() }

    val permissionLauncher = rememberLauncherForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { granted ->
        permissionsOk = granted.containsAll(HealthConnectSource.PERMISSIONS)
        status = if (permissionsOk) "разрешения выданы" else "разрешения выданы не полностью"
    }

    LaunchedEffect(Unit) {
        if (availability == HealthConnectClient.SDK_AVAILABLE) {
            permissionsOk = runCatching { source.hasAllPermissions() }.getOrDefault(false)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Mibro Bridge", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Забирает данные Mibro Fit из Health Connect и отправляет на wattpeaks.ru.",
            style = MaterialTheme.typography.bodyMedium
        )

        when (availability) {
            HealthConnectClient.SDK_UNAVAILABLE ->
                Warning("Health Connect на этом устройстве недоступен.")
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED ->
                Warning("Нужно обновить Health Connect через Play Маркет.")
        }

        OutlinedTextField(
            value = baseUrl,
            onValueChange = { baseUrl = it },
            label = { Text("Адрес сайта") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = token,
            onValueChange = { token = it },
            label = { Text("Токен привязки из кабинета") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Switch(checked = mibroOnly, onCheckedChange = { mibroOnly = it })
            Text("Только записи Mibro Fit")
        }

        Button(
            onClick = {
                prefs.baseUrl = baseUrl
                prefs.pairingToken = token
                prefs.filterMibroOnly = mibroOnly
                SyncWorker.schedule(context)
                status = "настройки сохранены, автосинхронизация раз в час включена"
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Сохранить и включить автосинхронизацию") }

        Button(
            onClick = { permissionLauncher.launch(HealthConnectSource.PERMISSIONS) },
            enabled = availability == HealthConnectClient.SDK_AVAILABLE,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (permissionsOk) "Разрешения выданы, проверить ещё раз" else "Выдать доступ к Health Connect")
        }

        Button(
            onClick = {
                busy = true
                status = "синхронизация..."
                scope.launch {
                    prefs.baseUrl = baseUrl
                    prefs.pairingToken = token
                    prefs.filterMibroOnly = mibroOnly
                    val result = withContext(Dispatchers.IO) { runManualSync(context) }
                    status = result
                    busy = false
                }
            },
            enabled = !busy && availability == HealthConnectClient.SDK_AVAILABLE,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Синхронизировать сейчас") }

        Button(
            onClick = {
                prefs.changesToken = null
                status = "курсор сброшен, следующая синхронизация будет с засевом"
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Сбросить курсор") }

        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = status,
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun Warning(text: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Text(text, modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
    }
}

/**
 * Ручной прогон. Использует ту же логику, что и воркер: гоняем воркер напрямую
 * было бы аккуратнее, но для кнопки «сейчас» проще позвать его тело.
 */
private suspend fun runManualSync(context: android.content.Context): String {
    val prefs = Prefs(context)
    val source = HealthConnectSource(context)
    return try {
        if (!prefs.isConfigured()) return "заполни адрес и токен"
        if (!source.hasAllPermissions()) return "нет разрешений Health Connect"

        val uploader = Uploader(prefs)
        val existing = prefs.changesToken
        val sent: Int
        if (existing == null) {
            val fresh = source.newChangesToken()
            val records = source.readRecent(7)
                .let { if (prefs.filterMibroOnly) it.filter { r -> r.metadata.dataOrigin.packageName == Prefs.MIBRO_PACKAGE } else it }
                .map { it.toJson() }
            sent = uploader.upload(records, emptyList())
            prefs.changesToken = fresh
        } else {
            val changes = source.readChanges(existing)
            if (changes.expired) {
                prefs.changesToken = null
                return "курсор протух, нажми ещё раз — сделаем засев"
            }
            val records = changes.upserts
                .let { if (prefs.filterMibroOnly) it.filter { r -> r.metadata.dataOrigin.packageName == Prefs.MIBRO_PACKAGE } else it }
                .map { it.toJson() }
            sent = uploader.upload(records, changes.deletions)
            prefs.changesToken = changes.nextToken
        }
        prefs.lastStatus = "отправлено записей: $sent"
        prefs.lastStatus
    } catch (e: Exception) {
        val msg = "ошибка: ${e.message}"
        prefs.lastStatus = msg
        msg
    }
}
