package ru.wattpeaks.bridge

import android.content.Context

/**
 * Настройки приложения. SharedPreferences, потому что данных тут на пять строк.
 */
class Prefs(context: Context) {

    private val sp = context.getSharedPreferences("mibro_bridge", Context.MODE_PRIVATE)

    var baseUrl: String
        get() = sp.getString(KEY_BASE_URL, DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL
        set(value) = sp.edit().putString(KEY_BASE_URL, value.trimEnd('/')).apply()

    /** Одноразовый токен привязки, выданный в кабинете атлета на сайте. */
    var pairingToken: String
        get() = sp.getString(KEY_TOKEN, "") ?: ""
        set(value) = sp.edit().putString(KEY_TOKEN, value.trim()).apply()

    /** Токен инкрементальной выборки Health Connect. Пусто — значит ещё не инициализировались. */
    var changesToken: String?
        get() = sp.getString(KEY_CHANGES, null)
        set(value) = sp.edit().putString(KEY_CHANGES, value).apply()

    /** Читать только записи от приложения Mibro Fit, игнорируя остальные источники. */
    var filterMibroOnly: Boolean
        get() = sp.getBoolean(KEY_FILTER, true)
        set(value) = sp.edit().putBoolean(KEY_FILTER, value).apply()

    var lastStatus: String
        get() = sp.getString(KEY_STATUS, "ещё не синхронизировались") ?: ""
        set(value) = sp.edit().putString(KEY_STATUS, value).apply()

    fun isConfigured(): Boolean = baseUrl.isNotBlank() && pairingToken.isNotBlank()

    companion object {
        const val DEFAULT_BASE_URL = "https://wattpeaks.ru"

        /** Пакет приложения Mibro Fit. Проверь у себя: adb shell pm list packages | grep mibro */
        const val MIBRO_PACKAGE = "com.xiaoxun.xunoversea.mibrofit"

        private const val KEY_BASE_URL = "base_url"
        private const val KEY_TOKEN = "pairing_token"
        private const val KEY_CHANGES = "changes_token"
        private const val KEY_FILTER = "filter_mibro"
        private const val KEY_STATUS = "last_status"
    }
}
