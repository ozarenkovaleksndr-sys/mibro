package ru.wattpeaks.bridge

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Отправка на wattpeaks.ru. Батчами, чтобы не улететь в таймаут на пульсовых
 * записях — их за сутки набегает много.
 */
class Uploader(private val prefs: Prefs) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /** Возвращает число отправленных записей или кидает IOException. */
    fun upload(records: List<JSONObject>, deletions: List<String>): Int {
        var sent = 0
        records.chunked(BATCH_SIZE).forEach { chunk ->
            postBatch(chunk, emptyList())
            sent += chunk.size
        }
        if (deletions.isNotEmpty()) {
            deletions.chunked(BATCH_SIZE).forEach { chunk ->
                postBatch(emptyList(), chunk)
            }
        }
        return sent
    }

    private fun postBatch(records: List<JSONObject>, deletions: List<String>) {
        val payload = JSONObject()
            .put("source", "health_connect")
            .put("device", android.os.Build.MODEL)
            .put("sentAt", java.time.Instant.now().toString())
            .put("records", JSONArray(records))
            .put("deletedIds", JSONArray(deletions))

        val request = Request.Builder()
            .url("${prefs.baseUrl}$ENDPOINT")
            .header("Authorization", "Bearer ${prefs.pairingToken}")
            .header("Accept", "application/json")
            .post(payload.toString().toRequestBody(JSON_MEDIA))
            .build()

        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("HTTP ${response.code}: ${response.body?.string()?.take(300)}")
            }
        }
    }

    companion object {
        const val ENDPOINT = "/api/imports/health-connect"
        private const val BATCH_SIZE = 200
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    }
}
